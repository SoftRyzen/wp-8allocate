<?php
get_header ();
	
	echo rb_vc_shortcode_sc_our_team( array('hide_meta' => true) );

get_footer ();
?>