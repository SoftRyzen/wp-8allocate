<?php
get_header ();
	
	echo rb_vc_shortcode_sc_case_study();

get_footer ();
?>