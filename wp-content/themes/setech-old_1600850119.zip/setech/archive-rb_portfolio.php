<?php
get_header ();

	echo rb_vc_shortcode_sc_portfolio();

get_footer ();
?>