<?php

add_action( 'after_setup_theme', 'rb_child_theme_setup' );
function rb_child_theme_setup() {
    load_child_theme_textdomain( 'setech', get_stylesheet_directory() . '/languages' );
}

add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles', 11 );
function my_theme_enqueue_styles() {
    wp_enqueue_style( 'child-style', get_stylesheet_uri() );
}

?>
